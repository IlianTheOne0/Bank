#ifndef DATA_PATHS_H
#define DATA_PATHS_H

#include "Providers/bank_systemProvider.h"
#include "Queries/bank_db-Queries.h"

#endif