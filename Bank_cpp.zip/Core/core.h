#pragma once
#ifndef CORE_H
#define CORE_H

#include "Logger/logger.h"

#endif