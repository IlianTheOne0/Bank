#ifndef CORE_CONFIG_H
#define CORE_CONFIG_H

#include <iostream>
#include <Windows.h>
#include <string>

using std::cout;
using std::endl;

using std::string;

#endif