#ifndef PRESENTATION_CONFIG_H
#define PRESENTATION_CONFIG_H

#include "mainLib.h"
#include "cfg/cfg.h"

#include <iostream>

using std::cout;
using std::endl;

using std::exception;

using namespace::ConnectionConfig;

#endif