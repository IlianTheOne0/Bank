#ifndef RANDOM_GENERATOR
#define RANDOM_GENERATOR

long long generateRandomLongLong(long long min, long long max);

#endif
