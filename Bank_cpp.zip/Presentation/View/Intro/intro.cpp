#include "../view.h"

void View::Intro()
{
	cout << "Run app" << endl;
}