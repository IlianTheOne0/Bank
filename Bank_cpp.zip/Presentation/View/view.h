#ifndef VIEW_H
#define VIEW_H

#include "../../Core/Libs/presentationConfig.h"

class View
{
public:
	static void Intro();
};

#endif