#ifndef TRANSACTION_STATUS_ENUM_H
#define TRANSACTION_STATUS_ENUM_H

enum TransactionStatus
{
	pending = 0,
	completed = 1,
	canceled = 2
};

#endif