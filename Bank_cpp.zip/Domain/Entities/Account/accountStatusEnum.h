#ifndef ACCOUNT_STATUS_ENUM_H
#define ACCOUNT_STATUS_ENUM_H

enum AccountStatus
{
	active = 0,
	frozen = 1,
	closed = 2
};

#endif