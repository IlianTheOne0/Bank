create function check_transaction() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW.from_account_id IS NOT NULL AND (SELECT is_income FROM operation_types WHERE operation_type_id = NEW.operation_type) = TRUE) THEN
        RAISE EXCEPTION 'Invalid operation: income transaction cannot have from_account_id';
    ELSIF (NEW.from_account_id IS NULL AND (SELECT is_income FROM operation_types WHERE operation_type_id = NEW.operation_type) = FALSE) THEN
        RAISE EXCEPTION 'Invalid operation: expense transaction must have from_account_id';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_transaction() owner to sa;

