create function process_transaction() returns trigger
    language plpgsql
as
$$
DECLARE
    op_type RECORD;
BEGIN
    SELECT * INTO op_type FROM operation_types
    WHERE operation_type_id = NEW.operation_type;

    IF op_type.is_income THEN
        UPDATE accounts
        SET balance = balance + NEW.amount
        WHERE account_id = NEW.to_account_id;
    ELSE
        UPDATE accounts
        SET balance = balance - NEW.amount
        WHERE account_id = NEW.from_account_id;
    END IF;

    NEW.status := 'COMPLETED';
    RETURN NEW;

EXCEPTION
    WHEN others THEN
        NEW.status := 'CANCELED';
        RAISE NOTICE 'Transaction failed: %', SQLERRM;
        RETURN NEW;
END;
$$;

alter function process_transaction() owner to sa;

